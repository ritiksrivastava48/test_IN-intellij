package com.GITPRACTICE.gitpractice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GitpracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(GitpracticeApplication.class, args);
	}

}
